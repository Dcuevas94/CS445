package edu.iit.cs445.VIN_Cuevas;

public enum WineVariety {
	RED,WHITE,ROSE;
}
