package edu.iit.cs445.VIN_Cuevas;

public enum WineType {
	TABLE,SWEET,SPARKLING;
}
