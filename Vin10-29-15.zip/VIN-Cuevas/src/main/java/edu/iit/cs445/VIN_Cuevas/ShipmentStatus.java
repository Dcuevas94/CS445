package edu.iit.cs445.VIN_Cuevas;

public enum ShipmentStatus {
	DELIVERED, PENDING, RETURNED, CANCELLED;
}
